import java.awt.*;

public class Player {
    private int x, y, width, height;
    private int velocityY = 0;
    private final int GRAVITY = 1;

    public Player(int x, int y) {
        this.x = x;
        this.y = y;
        this.width = 50;
        this.height = 50;
    }

    public void update(boolean gravityFlipped) {
        velocityY += gravityFlipped ? -GRAVITY : GRAVITY;
        y += velocityY;

        if (y > 550) {
            y = 550;
            velocityY = 0;
        }
        if (y < 0) {
            y = 0;
            velocityY = 0;
        }
    }

    public void draw(Graphics g) {
        g.setColor(Color.BLUE);
        g.fillRect(x, y, width, height);
    }

    public boolean collidesWith(obstacle obstacle) {
        return new Rectangle(x, y, width, height).intersects(obstacle.getBounds());
    }
}
