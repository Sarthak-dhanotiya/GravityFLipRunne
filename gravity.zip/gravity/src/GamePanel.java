import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

public class GamePanel extends JPanel implements ActionListener, KeyListener {
    private Timer timer;
    private Player player;
    private ArrayList<obstacle> obstacles;
    private boolean gravityFlipped = false;
    private int score = 0;

    public GamePanel() {
        this.setFocusable(true);
        this.addKeyListener(this);
        player = new Player(100, 450);
        obstacles = new ArrayList<>();
        timer = new Timer(20, this);  // Fixed: Use javax.swing.Timer
    }

    public void startGame() {
        timer.start();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, 800, 600);

        player.draw(g);
        for (obstacle obstacle : obstacles) {
            obstacle.draw(g);
        }

        g.setColor(Color.WHITE);
        g.drawString("Score: " + score, 20, 20);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        player.update(gravityFlipped);
        if (new Random().nextInt(100) < 3) {
            obstacles.add(new obstacle(800));
        }

        for (obstacle obstacle : obstacles) {
            obstacle.update();
            if (player.collidesWith(obstacle)) {
                timer.stop();
            }
        }

        score++;
        repaint();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            gravityFlipped = !gravityFlipped;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {}

    @Override
    public void keyTyped(KeyEvent e) {}
}
