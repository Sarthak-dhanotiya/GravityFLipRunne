import java.awt.*;

public class obstacle {
    private int x, y, width, height;

    public obstacle(int startX) {
        this.x = startX;
        this.y = (Math.random() > 0.5) ? 550 : 100;
        this.width = 50;
        this.height = 50;
    }

    public void update() {
        x -= 5;
    }

    public void draw(Graphics g) {
        g.setColor(Color.RED);
        g.fillRect(x, y, width, height);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, width, height);
    }
}
